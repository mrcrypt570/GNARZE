life=15
name="The Wolf"
isChar=False
att=3
dff=6
dxx=5
prr=5
items=[]

def deathText():
    print('''
THE WOLF CRUMPLES DEAD AT YOUR FEET AFTER YOU BURY 
YOUR SWORD IN ITS HEAD. YOU TAKE A MOMENT TO HONOR AND
LAMENT THE NECESSITY OF HIS DEATH, BUT IT WAS EITHER
HIM OR YOU.
''')
    return