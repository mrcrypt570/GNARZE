name="Bandit 02"
isChar=False
life=20
att=4
dff=4
dxx=5
prr=4
items=[]

def deathText():
    print('''
THE SECOND BANDIT PROVED A SOMEWHAT SKILLED FIGHTER,
ALTHOUGH IT DIDN'T TAKE LONG FOR YOUR BLADE TO FIND
ITS MARK ONE TOO MANY TIMES.

HIS CORPSE LAY AT YOUR FEET.
''')
    return