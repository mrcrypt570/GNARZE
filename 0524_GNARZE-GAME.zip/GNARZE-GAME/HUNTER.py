name="The Hunter"
isChar=False
life=30
att=4
dff=8
dxx=5
prr=5
items=[]

def deathText():
    print('''
Looking down his corpse, you realize this must be the Hunter.
He was as formidable a foe as you'd expected.

"What a shame," you say aloud, for the legacy of such
a legend ends with you.
''')
    return