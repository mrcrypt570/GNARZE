name="Bandit Leader"
isChar=False
life=20
att=4
dff=5
dxx=5
prr=5
items=[]

def deathText():
    print('''
THE BANDIT LEADER MAKES ONE FINAL LUNGE WITH HIS SWORD,
BUT YOU EASILY PARRY AND REPOST INTO HIS EXPOSED CHEST.
''')
    return