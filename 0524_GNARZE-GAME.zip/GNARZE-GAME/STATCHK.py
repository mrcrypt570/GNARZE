#CALCULATE THE SUCCESS OR FAILURE OF A STATISTIC CHECK
import random

def checkSTAT(stat,mod):
    dice=random.randint(1, 6) #dice roll for modifier
    checkResult=(dice + mod) #add modifier to att statistic for total attack result
    #print(str(stat) + "    " + str(dice) + "    " + str(checkResult))
    if(checkResult<=stat):
        return True
    else:
        return False